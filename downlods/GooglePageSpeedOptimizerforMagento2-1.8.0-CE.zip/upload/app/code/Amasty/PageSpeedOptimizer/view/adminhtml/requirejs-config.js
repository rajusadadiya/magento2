var config = {
    map: {
        '*': {
            render_mobile: 'Amasty_PageSpeedOptimizer/js/render_mobile',
            render_desktop: 'Amasty_PageSpeedOptimizer/js/render_desktop',
        }
    }
};
